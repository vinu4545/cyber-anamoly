"""SENTINEL AI backend: real Isolation Forest inference, SQLite history, investigations.
Fields marked simulated (IPs, protocol, timestamp) are generated; they are NOT in the model input."""
import hashlib, io, json, sqlite3, time, uuid
from datetime import datetime, timedelta, timezone
from pathlib import Path
import joblib, numpy as np, pandas as pd
from fastapi import Body, FastAPI, File, HTTPException, Query, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import Response
from sklearn.metrics import (average_precision_score, confusion_matrix, f1_score,
                             precision_score, recall_score, roc_auc_score)

ROOT = Path(__file__).resolve().parent.parent
MODEL_DIR, DATA = ROOT / "model", ROOT / "data"
DATA.mkdir(exist_ok=True)
DB = DATA / "sentinel.db"
SIMULATED = ["source_ip", "destination_ip", "protocol", "timestamp"]
MAX_ROWS = 200_000

app = FastAPI(title="SENTINEL AI API")
app.add_middleware(CORSMiddleware, allow_origins=["http://localhost:5173"], allow_methods=["*"], allow_headers=["*"])
_m = {}

def engine():
    """Load the trained model, scaler and config once. Never fall back to fake logic."""
    if not _m:
        try:
            _m.update(cfg=json.load(open(MODEL_DIR / "config.json")),
                      model=joblib.load(MODEL_DIR / "iforest.joblib"),
                      scaler=joblib.load(MODEL_DIR / "scaler.joblib"))
        except FileNotFoundError as e:
            raise HTTPException(503, f"Model file missing: {e.filename}. See README, step 2.")
    return _m

def db():
    c = sqlite3.connect(DB); c.row_factory = sqlite3.Row
    c.executescript("""CREATE TABLE IF NOT EXISTS sessions(id TEXT PRIMARY KEY, file TEXT, rows INT, created TEXT,
        algo TEXT, pct INT, anomalies INT, seconds REAL, summary TEXT);
      CREATE TABLE IF NOT EXISTS records(sid TEXT, rid INT, score REAL, flagged INT, label TEXT, src TEXT, dst TEXT,
        proto TEXT, ts TEXT, port INT);
      CREATE INDEX IF NOT EXISTS ix ON records(sid, score);
      CREATE TABLE IF NOT EXISTS inv(id TEXT PRIMARY KEY, sid TEXT, rid INT, severity TEXT, status TEXT, created TEXT, score REAL);""")
    return c

def slog(a): return np.sign(a) * np.log1p(np.abs(a))

def simulate(sid, n, ports):
    """Deterministic dummy metadata (seeded by session id), independent of labels."""
    rng = np.random.default_rng(int(hashlib.md5(sid.encode()).hexdigest()[:8], 16))
    src = rng.choice([f"192.168.10.{i}" for i in range(10, 41)], n)
    dst = rng.choice([f"10.0.0.{i}" for i in (5, 8, 12, 20, 31)], n)
    proto = np.where(np.isin(ports, (53, 123, 5353)), "UDP", "TCP")
    t0 = datetime.now(timezone.utc) - timedelta(hours=24)
    gaps = rng.exponential(1.0, n); secs = np.cumsum(gaps) / gaps.sum() * 86400
    return src, dst, proto, [(t0 + timedelta(seconds=float(s))).isoformat(timespec="seconds") for s in secs]

def read_csv(raw: bytes):
    df = pd.read_csv(io.BytesIO(raw), skipinitialspace=True, low_memory=False)
    df.columns = df.columns.astype(str).str.strip()
    return df

@app.get("/api/health")
def health():
    return {"status": "ok", "model_loaded": (MODEL_DIR / "iforest.joblib").exists()}

@app.post("/api/dataset/upload")
async def upload(file: UploadFile = File(...)):
    if not (file.filename or "").lower().endswith(".csv"): raise HTTPException(400, "Only .csv files are accepted.")
    raw = await file.read()
    try: df = read_csv(raw)
    except Exception as e: raise HTTPException(400, f"Could not parse CSV: {e}")
    if len(df) == 0: raise HTTPException(400, "The file has no rows.")
    if len(df) > MAX_ROWS: raise HTTPException(413, f"Too many rows ({len(df):,}); limit is {MAX_ROWS:,}.")
    feats = engine()["cfg"]["features"]
    num = df.select_dtypes(include=[np.number])
    uid = uuid.uuid4().hex[:12]; df.to_pickle(DATA / f"up_{uid}.pkl")
    missing = [c for c in feats if c not in df.columns]
    lab = df["Label"].value_counts().to_dict() if "Label" in df.columns else None
    return {"upload_id": uid, "file": file.filename, "size_bytes": len(raw), "rows": len(df), "columns": df.shape[1],
            "dtypes": {c: str(t) for c, t in df.dtypes.items()},
            "missing_values": int(df.isna().sum().sum()), "infinite_values": int(np.isinf(num).sum().sum()),
            "duplicate_rows": int(df.duplicated().sum()), "label_present": lab is not None, "label_counts": lab,
            "compatible": not missing, "missing_model_features": missing,
            "preview": json.loads(df.head(10).replace([np.inf, -np.inf], None).to_json(orient="records"))}

@app.post("/api/model/detect")
def detect(body: dict = Body(...)):
    uid, pct = body.get("upload_id"), str(body.get("threshold_percentile", 95))
    e = engine(); cfg = e["cfg"]; feats = cfg["features"]
    if pct not in cfg["thresholds"]: raise HTTPException(422, f"threshold_percentile must be one of {list(cfg['thresholds'])}")
    p = DATA / f"up_{uid}.pkl"
    if not uid or not p.exists(): raise HTTPException(404, "Unknown upload_id. Upload the file first.")
    df = pd.read_pickle(p); stages = []; T = time.perf_counter()
    def stage(name, t): stages.append({"stage": name, "seconds": round(time.perf_counter() - t, 3)})
    t = time.perf_counter()                                               # 1 validate
    missing = [c for c in feats if c not in df.columns]
    if missing: raise HTTPException(422, {"error": "incompatible columns", "missing": missing[:10], "count": len(missing)})
    X = df[feats].apply(pd.to_numeric, errors="coerce").replace([np.inf, -np.inf], np.nan)
    ok = X.notna().all(axis=1).values; skipped = int((~ok).sum()); stage("validate", t)
    if not ok.any(): raise HTTPException(422, "No valid rows after removing missing or infinite values.")
    t = time.perf_counter(); Xv = X[ok]; Z = e["scaler"].transform(pd.DataFrame(slog(Xv.values), columns=feats)); stage("preprocess", t)   # 2 same pipeline as training
    t = time.perf_counter(); score = -e["model"].score_samples(Z); stage("isolation_forest", t)           # 3 score
    thr = cfg["thresholds"][pct]; flagged = score > thr
    sid = uuid.uuid4().hex[:10]; n = len(score)
    rid = np.where(ok)[0] + 1                                              # record id = original row number
    label = df["Label"].astype(str).values[ok] if "Label" in df.columns else None   # evaluation only, never a feature
    ports = pd.to_numeric(df["Destination Port"], errors="coerce").fillna(0).astype(int).values[ok] if "Destination Port" in df.columns else np.zeros(n, int)
    src, dst, proto, ts = simulate(sid, n, ports)
    ev = None
    if label is not None and len(set(label)) > 1 and (label == "BENIGN").any():
        y = (label != "BENIGN").astype(int)
        ev = {"precision": float(precision_score(y, flagged, zero_division=0)), "recall": float(recall_score(y, flagged)),
              "f1": float(f1_score(y, flagged, zero_division=0)), "false_positive_rate": float(flagged[y == 0].mean()),
              "roc_auc": float(roc_auc_score(y, score)), "pr_auc": float(average_precision_score(y, score)),
              "confusion": dict(zip(["tn", "fp", "fn", "tp"], map(int, confusion_matrix(y, flagged).ravel()))),
              "recall_by_label": {l: float(flagged[label == l].mean()) for l in sorted(set(label)) if l != "BENIGN"}}
    secs = round(time.perf_counter() - T, 3)
    hist, edges = np.histogram(score, bins=30)
    hn = np.histogram(score[~flagged], bins=edges)[0]
    summary = {"session_id": sid, "records_analysed": n, "skipped_invalid_rows": skipped, "normal": int((~flagged).sum()),
               "anomalous": int(flagged.sum()), "anomaly_pct": round(100 * float(flagged.mean()), 2), "threshold": thr,
               "threshold_percentile": int(float(pct)), "processing_seconds": secs, "stages": stages, "evaluation": ev,
               "score_distribution": [{"from": round(float(edges[i]), 4), "to": round(float(edges[i + 1]), 4),
                                       "normal": int(hn[i]), "flagged": int(hist[i] - hn[i])} for i in range(30)],
               "simulated_fields": SIMULATED}
    np.save(DATA / f"z_{sid}.npy", Z.astype("float32")); Xv.to_pickle(DATA / f"x_{sid}.pkl")
    sev = lambda s: "High" if s > cfg["thresholds"]["99"] else "Medium" if s > cfg["thresholds"]["97"] else "Low"
    now = datetime.now(timezone.utc).isoformat(timespec="seconds")
    c = db()
    c.execute("INSERT INTO sessions VALUES(?,?,?,?,?,?,?,?,?)", (sid, body.get("file", f"upload {uid}"), n, now, "Isolation Forest", int(float(pct)), int(flagged.sum()), secs, json.dumps(summary)))
    c.executemany("INSERT INTO records VALUES(?,?,?,?,?,?,?,?,?,?)",
                  [(sid, int(rid[i]), float(score[i]), int(flagged[i]), None if label is None else label[i], src[i], dst[i], proto[i], ts[i], int(ports[i])) for i in range(n)])
    c.executemany("INSERT INTO inv VALUES(?,?,?,?,?,?,?)", [(f"INV-{sid}-{int(rid[i])}", sid, int(rid[i]), sev(score[i]), "New", now, float(score[i])) for i in np.where(flagged)[0][:5000]])
    c.commit(); c.close()
    return summary

@app.get("/api/model/metrics")
def metrics():
    p = MODEL_DIR / "metrics.json"
    if not p.exists(): raise HTTPException(404, "No evaluation results available. Copy metrics.json from your notebook export.")
    return json.load(open(p))

@app.get("/api/analysis/history")
def history():
    c = db(); r = [dict(x) for x in c.execute("SELECT id,file,rows,created,algo,pct,anomalies,seconds FROM sessions ORDER BY created DESC")]; c.close(); return r

@app.get("/api/analysis/{sid}")
def session(sid: str):
    c = db(); r = c.execute("SELECT summary FROM sessions WHERE id=?", (sid,)).fetchone(); c.close()
    if not r: raise HTTPException(404, "Unknown session.")
    return json.loads(r["summary"])

@app.get("/api/analysis/{sid}/records")
def records(sid: str, page: int = 1, page_size: int = Query(25, le=200), status: str = "all", search: str = "", sort: str = "score_desc"):
    q, a = "FROM records WHERE sid=?", [sid]
    if status in ("normal", "anomalous"): q += " AND flagged=?"; a.append(int(status == "anomalous"))
    if search: q += " AND (src LIKE ? OR dst LIKE ? OR CAST(rid AS TEXT)=?)"; a += [f"%{search}%", f"%{search}%", search]
    order = {"score_desc": "score DESC", "score_asc": "score ASC", "id": "rid ASC"}.get(sort, "score DESC")
    c = db(); tot = c.execute("SELECT COUNT(*) " + q, a).fetchone()[0]
    rows = [dict(x) for x in c.execute(f"SELECT rid,score,flagged,label,src,dst,proto,ts,port {q} ORDER BY {order} LIMIT ? OFFSET ?", a + [page_size, (page - 1) * page_size])]; c.close()
    return {"total": tot, "page": page, "simulated_fields": SIMULATED,
            "records": [{"record_id": r["rid"], "anomaly_score": round(r["score"], 4), "prediction": "ANOMALOUS" if r["flagged"] else "NORMAL",
                         "actual_label": r["label"], "source_ip": r["src"], "destination_ip": r["dst"], "protocol": r["proto"],
                         "timestamp": r["ts"], "destination_port": r["port"]} for r in rows]}

@app.get("/api/analysis/{sid}/records/{rid}")
def record_detail(sid: str, rid: int, top: int = 8):
    """Feature deviations from the normal baseline: contextual indicators, not an exact Isolation Forest explanation."""
    c = db(); r = c.execute("SELECT * FROM records WHERE sid=? AND rid=?", (sid, rid)).fetchone(); c.close()
    if not r: raise HTTPException(404, "Unknown record.")
    e = engine(); feats = e["cfg"]["features"]
    X = pd.read_pickle(DATA / f"x_{sid}.pkl"); Z = np.load(DATA / f"z_{sid}.npy")
    i = int(np.where(X.index.values + 1 == rid)[0][0]); mu = e["scaler"].mean_
    dev = [{"feature": feats[j], "value": float(X.iloc[i, j]), "z_score": round(float(Z[i, j]), 2),
            "typical_normal": float(np.sign(mu[j]) * np.expm1(abs(mu[j])))} for j in np.argsort(-np.abs(Z[i]))[:top]]
    return {"record_id": rid, "anomaly_score": round(r["score"], 4), "prediction": "ANOMALOUS" if r["flagged"] else "NORMAL",
            "actual_label": r["label"], "source_ip": r["src"], "destination_ip": r["dst"], "protocol": r["proto"], "timestamp": r["ts"],
            "deviations": dev, "simulated_fields": SIMULATED,
            "note": "Deviations are contextual indicators measured against normal traffic, not an exact explanation of the model's decision."}

@app.get("/api/analysis/{sid}/export.csv")
def export(sid: str):
    c = db(); df = pd.read_sql_query("SELECT rid AS record_id, score AS anomaly_score, flagged, label AS actual_label, src AS source_ip_simulated, dst AS destination_ip_simulated, proto AS protocol_simulated, ts AS timestamp_simulated FROM records WHERE sid=? ORDER BY score DESC", c, params=[sid]); c.close()
    if df.empty: raise HTTPException(404, "Unknown session.")
    df["prediction"] = np.where(df.pop("flagged") == 1, "ANOMALOUS", "NORMAL")
    return Response(df.to_csv(index=False), media_type="text/csv", headers={"Content-Disposition": f"attachment; filename=sentinel_{sid}.csv"})

@app.get("/api/investigations")
def investigations(session_id: str = "", status: str = "", search: str = "", limit: int = Query(100, le=500)):
    q, a = "FROM inv WHERE 1=1", []
    for col, v in (("sid", session_id), ("status", status)):
        if v: q += f" AND {col}=?"; a.append(v)
    if search: q += " AND id LIKE ?"; a.append(f"%{search}%")
    c = db(); r = [dict(x) for x in c.execute(f"SELECT * {q} ORDER BY score DESC LIMIT ?", a + [limit])]; c.close(); return r

@app.patch("/api/investigations/{iid}")
def update_inv(iid: str, body: dict = Body(...)):
    if body.get("status") not in ("New", "Under Investigation", "Resolved", "False Positive"): raise HTTPException(422, "Invalid status.")
    c = db(); n = c.execute("UPDATE inv SET status=? WHERE id=?", (body["status"], iid)).rowcount; c.commit(); c.close()
    if not n: raise HTTPException(404, "Unknown investigation.")
    return {"id": iid, "status": body["status"]}
